# Test Chat

**Model:** claude-sonnet-4-20250514
**Created:** 10/16/2025, 8:42:30 AM
**Updated:** 10/16/2025, 3:03:09 PM
**Total Cost:** $0.0005
**Total Tokens:** 112 (20 in, 92 out)

---

## 👤 User - 10/16/2025, 8:44:15 AM

The Haiku model, what type of model is it?

---

## 🤖 Assistant - 10/16/2025, 8:44:18 AM

The Haiku model is an open-source machine learning model developed by DeepMind. Specifically, it is a language model designed for natural language processing tasks. Haiku is built using JAX, a numerical computing library, and provides a neural network library with a focus on modularity and ease of use. It is part of the broader JAX ecosystem and is particularly useful for researchers and developers working on machine learning projects.

*Cost: $0.0005 | Tokens: 112 (20 in, 92 out)*

---

